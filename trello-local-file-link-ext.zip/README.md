# trello-local-file-link-ext
Trello Local File Link Chrome Extension

A chrome extension that was quickly built to enable the easy insertion of local file links onto Trello cards.

Will work on any editable field on the Trello website. Just right click an editable field and select "Paste Local File Link".
